sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History"
], function(BaseController, MessageBox, Utilities, History) {
	"use strict";

	return BaseController.extend("com.sap.build.standard.hub365.controller.ContactUs", {
		handleRouteMatched: function(oEvent) {
			var sAppId = "App5d9c6e18773bac04320ea462";

			var oParams = {};

			if (oEvent.mParameters.data.context) {
				this.sContext = oEvent.mParameters.data.context;

			} else {
				if (this.getOwnerComponent().getComponentData()) {
					var patternConvert = function(oParam) {
						if (Object.keys(oParam).length !== 0) {
							for (var prop in oParam) {
								if (prop !== "sourcePrototype" && prop.includes("Set")) {
									return prop + "(" + oParam[prop][0] + ")";
								}
							}
						}
					};

					this.sContext = patternConvert(this.getOwnerComponent().getComponentData().startupParameters);

				}
			}

			if (!this.sContext) {
				this.sContext = "QuerySet('Meeting Room Booking')";
			}

			var oPath;

			if (this.sContext) {
				oPath = {
					path: "/" + this.sContext,
					parameters: oParams
				};
				this.getView().bindObject(oPath);
			}

		},
		formatDateTimeUTCtoLocale: function(utcDate) {
			return utcDate ? new Date(utcDate.getUTCFullYear(), utcDate.getUTCMonth(), utcDate.getUTCDate(), utcDate.getUTCHours(), utcDate.getUTCMinutes(), utcDate.getUTCSeconds()) : null;

		},
		formatDateTimeUTCtoLocaleForStartDate: function(utcDate) {
			return utcDate ? new Date(utcDate.getUTCFullYear(), utcDate.getUTCMonth(), utcDate.getUTCDate(), utcDate.getUTCHours(), utcDate.getUTCMinutes(), utcDate.getUTCSeconds()) : new Date(864000000000000);

		},
		_onButtonPress: function() {
			var oView = this.getView(),
				oController = this,
				status = true,
				requiredFieldInfo = [];
			if (requiredFieldInfo.length) {
				status = this.handleChangeValuestate(requiredFieldInfo, oView);
			}
			if (status) {
				return new Promise(function(fnResolve, fnReject) {
					var oModel = oController.oModel;

					var fnResetChangesAndReject = function(sMessage) {
						oModel.resetChanges();
						fnReject(new Error(sMessage));
					};
					if (oModel && oModel.hasPendingChanges()) {
						oModel.submitChanges({
							success: function(oResponse) {
								var oBatchResponse = oResponse.__batchResponses[0];
								var oChangeResponse = oBatchResponse.__changeResponses && oBatchResponse.__changeResponses[0];
								if (oChangeResponse && oChangeResponse.data) {
									var sNewContext = oModel.getKey(oChangeResponse.data);
									oView.unbindObject();
									oView.bindObject({
										path: "/" + sNewContext
									});
									if (window.history && window.history.replaceState) {
										window.history.replaceState(undefined, undefined, window.location.hash.replace(encodeURIComponent(oController.sContext), encodeURIComponent(sNewContext)));
									}
									oModel.refresh();
									fnResolve();
								} else if (oChangeResponse && oChangeResponse.response) {
									fnResetChangesAndReject(oChangeResponse.message);
								} else if (!oChangeResponse && oBatchResponse.response) {
									fnResetChangesAndReject(oBatchResponse.message);
								} else {
									oModel.refresh();
									fnResolve();
								}
							},
							error: function(oError) {
								fnReject(new Error(oError.message));
							}
						});
					} else {
						fnResolve();
					}
				}).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			}
		},
		handleChangeValuestate: function(requiredFieldInfo, oView) {
			var status = true;
			if (requiredFieldInfo) {
				requiredFieldInfo.forEach(function(requiredinfo) {
					var input = oView.byId(requiredinfo.id);
					if (input) {
						input.setValueState("None"); //initially set ValueState to None
						if (input.getValue() === '') {
							input.setValueState("Error"); //input is blank set ValueState to error
							status = false;
						} else if (input.getDateValue && !input._bValid) { //since 1.64 ui5 will be providing a function 'isValidValue' that can be used here.
							input.setValueState("Error"); //Invalid Date set ValueState to error
							status = false;
						}
					}
				});
			}
			return status;

		},
		applyFiltersAndSorters: function(sControlId, sAggregationName, chartBindingInfo) {
			if (chartBindingInfo) {
				var oBindingInfo = chartBindingInfo;
			} else {
				var oBindingInfo = this.getView().byId(sControlId).getBindingInfo(sAggregationName);
			}
			var oBindingOptions = this.updateBindingOptions(sControlId);
			this.getView().byId(sControlId).bindAggregation(sAggregationName, {
				model: oBindingInfo.model,
				path: oBindingInfo.path,
				parameters: oBindingInfo.parameters,
				template: oBindingInfo.template,
				templateShareable: true,
				sorter: oBindingOptions.sorters,
				filters: oBindingOptions.filters
			});

		},
		updateBindingOptions: function(sCollectionId, oBindingData, sSourceId) {
			this.mBindingOptions = this.mBindingOptions || {};
			this.mBindingOptions[sCollectionId] = this.mBindingOptions[sCollectionId] || {};

			var aSorters = this.mBindingOptions[sCollectionId].sorters;
			var aGroupby = this.mBindingOptions[sCollectionId].groupby;

			// If there is no oBindingData parameter, we just need the processed filters and sorters from this function
			if (oBindingData) {
				if (oBindingData.sorters) {
					aSorters = oBindingData.sorters;
				}
				if (oBindingData.groupby || oBindingData.groupby === null) {
					aGroupby = oBindingData.groupby;
				}
				// 1) Update the filters map for the given collection and source
				this.mBindingOptions[sCollectionId].sorters = aSorters;
				this.mBindingOptions[sCollectionId].groupby = aGroupby;
				this.mBindingOptions[sCollectionId].filters = this.mBindingOptions[sCollectionId].filters || {};
				this.mBindingOptions[sCollectionId].filters[sSourceId] = oBindingData.filters || [];
			}

			// 2) Reapply all the filters and sorters
			var aFilters = [];
			for (var key in this.mBindingOptions[sCollectionId].filters) {
				aFilters = aFilters.concat(this.mBindingOptions[sCollectionId].filters[key]);
			}

			// Add the groupby first in the sorters array
			if (aGroupby) {
				aSorters = aSorters ? aGroupby.concat(aSorters) : aGroupby;
			}

			var aFinalFilters = aFilters.length > 0 ? [new sap.ui.model.Filter(aFilters, true)] : undefined;
			return {
				filters: aFinalFilters,
				sorters: aSorters
			};

		},
		onInit: function() {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("ContactUs").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));

			this.oModel = this.getOwnerComponent().getModel();

			var oView = this.getView(),
				oData = {},
				self = this;
			var oModel = new sap.ui.model.json.JSONModel();
			oView.setModel(oModel, "staticDataModel");
			self.oBindingParameters = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231"] = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231"]["startDate"] = new Date("2018-07-01T07:00:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-1-appointments-sap_ui_unified_CalendarAppointment-1"] = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-1-appointments-sap_ui_unified_CalendarAppointment-1"]["startDate"] = new Date("2018-07-01T08:30:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-1-appointments-sap_ui_unified_CalendarAppointment-1"]["endDate"] = new Date("2018-07-01T10:30:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-1"] = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-1"]["startDate"] = new Date("2018-07-01T07:00:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-1"]["endDate"] = new Date("2018-07-01T09:30:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-2"] = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-2"]["startDate"] = new Date("2018-07-01T08:00:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-2"]["endDate"] = new Date("2018-07-01T10:00:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-3"] = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-3"]["startDate"] = new Date("2018-07-01T12:00:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-2-appointments-sap_ui_unified_CalendarAppointment-3"]["endDate"] = new Date("2018-07-01T14:30:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-3-appointments-sap_ui_unified_CalendarAppointment-1"] = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-3-appointments-sap_ui_unified_CalendarAppointment-1"]["startDate"] = new Date("2018-07-01T08:30:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-3-appointments-sap_ui_unified_CalendarAppointment-1"]["endDate"] = new Date("2018-07-01T11:00:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-3-appointments-sap_ui_unified_CalendarAppointment-2"] = {};

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-3-appointments-sap_ui_unified_CalendarAppointment-2"]["startDate"] = new Date("2018-07-01T12:00:00.000Z");

			oData["sap_Responsive_Page_0-content-sap_m_PlanningCalendar-1570534365231-rows-sap_m_PlanningCalendarRow-3-appointments-sap_ui_unified_CalendarAppointment-2"]["endDate"] = new Date("2018-07-01T14:00:00.000Z");

			oView.getModel("staticDataModel").setData(oData, true);

			function dateDimensionFormatter(oDimensionValue, sTextValue) {
				var oValueToFormat = sTextValue !== undefined ? sTextValue : oDimensionValue;
				if (oValueToFormat instanceof Date) {
					var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
						style: "short"
					});
					return oFormat.format(oValueToFormat);
				}
				return oValueToFormat;
			}

		},
		onAfterRendering: function() {

			var oChart,
				self = this,
				oBindingParameters = this.oBindingParameters,
				oView = this.getView();

		}
	});
}, /* bExport= */ true);
